const multer = require("multer");
const multerS3 = require('multer-s3');
var aws = require('aws-sdk');


exports.fileUpload = (req, res, next) => {

    console.log(req.body);
   

   // upload.single('file','email')
   const s3 = new aws.S3( {
    accessKeyId: 'DHDHLJ5QNXEHZTOY5AJA',
    secretAccessKey: 'xALNqGkroRscl2youUWeZEtJMzI9cL+3IeVwIBGAfms',
    region: 'spg1'
});
    var upload = multer({
        storage: multerS3({
            s3: s3,
            bucket: 'blogwebspace',
                acl: 'public-read',
            cacheControl: 'max-age=31536000',
            contentType: multerS3.AUTO_CONTENT_TYPE,
            metadata: function (req, file, cb) {
              cb(null, {fieldName: file.fieldname});
            },
    
            key: function (req, file,cb) {
                var s = file.originalname;
                var x= s.split('.');
    
                const key = `${req.query.email}/${file.originalname}`
                // `${Date.now().toString()}${path.extname(file.originalname)}`
                cb(null, key);
            }
          })
    });
    multer({ storage: upload }).single("image");

    return res.status(200).json({
        message: "success",
        //location: req.file.location
    })

};
  