const express = require("express");
const router = express.Router();
const multer = require("multer");
const multerS3 = require('multer-s3');
var aws = require('aws-sdk');

const AWSfileUpload = require("../controllers/awsfileupload");
const checkAuth = require("../middlewares/check-auth");
const s3 = new aws.S3( {
    accessKeyId: 'DHDHLJ5QNXEHZTOY5AJA',
    secretAccessKey: 'xALNqGkroRscl2youUWeZEtJMzI9cL+3IeVwIBGAfms',
    endpoint:'sgp1.digitaloceanspaces.com'
    // region: 'spg1'
});
//router.post("/fileupload", AWSfileUpload.fileUpload);
var upload = multer({
    storage: multerS3({
        s3: s3,
        bucket: 'blogwebspace',
        acl: 'public-read',
        cacheControl: 'max-age=31536000',
        contentType: multerS3.AUTO_CONTENT_TYPE,
        metadata: function (req, file, cb) {
          cb(null, {fieldName: file.fieldname});
        },

        key: function (req, file,cb) {
            const key = `${req.query.email}/${file.originalname}`
            // `${Date.now().toString()}${path.extname(file.originalname)}`
            cb(null, key);
        }
      })
});
router.post('/file',upload.single('file','email'),(req,res,next)=>{
     res.send({url: req.file.location})
      return;
})

module.exports = router;
